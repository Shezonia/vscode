#!/bin/sh

npm i
npm run electron
